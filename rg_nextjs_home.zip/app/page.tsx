'use client';

export default function Home() {
  return (
    <main style={{ padding: "40px", fontFamily: "sans-serif" }}>
      <h1>Royal Gambit Rewards</h1>
      <p>Home (/) page converted to Next.js.</p>
    </main>
  );
}
