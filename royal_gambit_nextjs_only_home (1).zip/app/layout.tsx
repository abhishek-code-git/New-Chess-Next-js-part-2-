
export const metadata = {
  title: "Royal Gambit Rewards",
  description: "Chess Game Application",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
